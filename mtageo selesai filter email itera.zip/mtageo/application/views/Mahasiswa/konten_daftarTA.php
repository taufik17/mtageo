<section class="content">
	<div class="box box-primary">

		<form role="form">
			<div class="box-body">

				<div class="form-group">
					<label for="exampleInputEmail1">Judul Proposal</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Judul TA">
				</div>

				<div class="form-group">
					<label for="exampleInputEmail1">Judul Laporan KP</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Judul Laporan KP">
				</div>

				<div class="form-group">
					<label for="exampleInputEmail1">Dosen Pembimbing 1</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Dosen Pembimbing 1">
				</div>

				<div class="form-group">
					<label>Dosen Pembimbing 2</label>
					<select class="form-control select2 select2-hidden-accessible" style="width: 100%;" tabindex="-1" aria-hidden="true">
						<option selected="selected">--</option>
						<option></option>
						<option>California</option>
						<option>Delaware</option>
						<option>Tennessee</option>
						<option>Texas</option>
						<option>Washington</option>
					</select>
				</div>

				<div class="form-group">
					<label for="exampleInputEmail1">Dosen Pembimbing 3 ( Opsional )</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Dosen Pembimbing 3">
				</div>

				<div class="form-group">
					<label for="exampleInputFile">File Proposal TA</label>
					<input type="file" id="exampleInputFile">
					<p class="help-block">File Max 10 Mb</p>
				</div>

				<div class="form-group">
					<label for="exampleInputFile">Transkrip Nilai</label>
					<input type="file" id="exampleInputFile">
					<p class="help-block">File Max 10 Mb</p>
				</div>

				<div class="form-group">
					<label for="exampleInputFile">CV</label>
					<input type="file" id="exampleInputFile">
					<p class="help-block">File Max 10 Mb</p>
				</div>

				</div>
				<div class="box-footer">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>
		</div>
	</section>
