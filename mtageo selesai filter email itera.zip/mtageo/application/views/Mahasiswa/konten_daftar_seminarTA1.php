<section class="content">
	<div class="box box-primary">

		<form role="form">
			<div class="box-body">

				<div class="form-group">
					<label for="exampleInputEmail1">Judul Proposal</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Judul TA didaptkan dari database sebelumnya" disabled>
				</div>

				<div class="form-group">
					<label for="exampleInputEmail1">Judul Laporan KP</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="didaptkan dari database sebelumnya" disabled>
				</div>

				<div class="form-group">
					<label for="exampleInputEmail1">Dosen Pembimbing 1</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Dosen Pembimbing 1 didaptkan dari database sebelumnya" disabled>
				</div>

				<div class="form-group">
					<label for="exampleInputEmail1">Dosen Pembimbing 2</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Dosen Pembimbing 2 didaptkan dari database sebelumnya" disabled>
				</div>

				<div class="form-group">
					<label for="exampleInputEmail1">Dosen Pembimbing 3 ( Opsional )</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Dosen Pembimbing 3 didaptkan dari database sebelumnya" disabled>
				</div>

				<div class="form-group">
					<label>Tanggal Seminar</label>
					<div class="input-group date">
						<div class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</div>
						<input type="text" class="form-control pull-right" id="datepicker">
					</div>
					<!-- /.input group -->
				</div>

				<div class="form-group">
					<label for="exampleInputEmail1">Ruangan Seminar</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Ruangan Seminar">
				</div>

				<div class="form-group">
					<label for="exampleInputFile">File Draft TA1</label>
					<input type="file" id="exampleInputFile">
					<p class="help-block">File Max 10 Mb</p>
				</div>

				</div>
				<div class="box-footer">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>
		</div>
	</section>
